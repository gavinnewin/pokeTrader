const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/user');
const { OAuth2Client } = require('google-auth-library');

const router = express.Router();

// Initialize Google OAuth client
const googleClient = new OAuth2Client(process.env.GOOGLE_CLIENT_ID);

// Register
router.post('/register', async (req, res) => {
  const { fullName, email, password } = req.body;
  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = new User({ fullName, email, password: hashedPassword });
    await user.save();
    res.status(201).json({ message: "User registered" });
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
});

// Login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ email });
    if (!user) return res.status(400).json({ error: "User not found" });

    const match = await bcrypt.compare(password, user.password);
    if (!match) return res.status(400).json({ error: "Invalid credentials" });

    const token = jwt.sign({ id: user._id }, "secret_key");
    res.json({
      token,
      fullName: user.fullName,
      email: user.email,
      profilePic: user.profilePic  // ✅ include this
    });
  } catch (err) {
    res.status(500).json({ error: "Login failed" });
  }
});

// Google Login
router.post('/google-login', async (req, res) => {
  const { credential } = req.body;
  
  try {
    // Verify the Google token
    const ticket = await googleClient.verifyIdToken({
      idToken: credential,
      audience: process.env.GOOGLE_CLIENT_ID
    });
    
    const payload = ticket.getPayload();
    const { email, name, picture } = payload;
    
    // Check if user exists
    let user = await User.findOne({ email });
    
    if (!user) {
      // Create new user if doesn't exist
      user = new User({
        fullName: name,
        email: email,
        profilePic: picture,
        googleId: payload.sub,
        // No password for Google users
      });
      await user.save();
    } else {
      // Update profile picture if changed
      if (picture && user.profilePic !== picture) {
        user.profilePic = picture;
        await user.save();
      }
    }
    
    // Generate JWT token
    const token = jwt.sign({ id: user._id }, "secret_key");
    
    res.json({
      token,
      fullName: user.fullName,
      email: user.email,
      profilePic: user.profilePic
    });
  } catch (error) {
    console.error('Google login error:', error);
    res.status(400).json({ error: "Google authentication failed" });
  }
});

module.exports = router;
